﻿namespace PeerageHRIS.Models.Time
{
    public class LeaveHistory
    {
    }
}
