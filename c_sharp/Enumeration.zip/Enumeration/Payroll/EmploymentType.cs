﻿namespace PeerageHRIS.Enumeration.Payroll
{
    // Enum for employment types
    public enum EmploymentType
    {
        FullTime,
        PartTime,
        Contract,
        Temporary,
        Internship
    }
}
