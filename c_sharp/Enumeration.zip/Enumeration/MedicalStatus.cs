﻿namespace PeerageHRIS.Enumeration
{
    public enum MedicalStatus
    {
        Fit,
        Unfit,
        Pending,
        Other
    }
}
