﻿namespace PeerageHRIS.Enumeration
{
    public enum RetirementRequirements
    {
       Experiences = 0,
       Ages = 1,
    }
}