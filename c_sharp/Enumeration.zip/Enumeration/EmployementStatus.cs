﻿namespace PeerageHRIS.Enumeration
{
    public enum EmployementStatus
    {
        Active, 
        Eligible,
        NoticeGiven,
        Rejected,
        Processing,
        Retired
    }
}