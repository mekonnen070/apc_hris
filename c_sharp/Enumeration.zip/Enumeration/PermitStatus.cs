﻿namespace PeerageHRIS.Enumeration
{
    public enum PermitStatus
    {
        Pending,
        Approved,
        Rejected
    }
}
