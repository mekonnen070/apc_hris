﻿namespace PeerageHRIS.Enumeration
{
    public enum TransferStatus
    {
        Pending,
        Approved,
        Rejected
    }
}
