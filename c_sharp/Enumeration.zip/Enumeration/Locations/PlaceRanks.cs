﻿namespace PeerageHRIS.Enumeration.Locations
{
    public enum PlaceRanks
    {
        First,
        Second,
        Third,
        Fourth,
        Fifth,
        Sixth,
    }
}
