﻿namespace PeerageHRIS.Enumeration
{
    public enum RecuritmentType
    {
        Military = 0,
        Civilian = 1,
    }
}