﻿namespace PeerageHRIS.Enumeration
{
    public enum RetirementApprovalStatus
    {
        Pending,
        Approved,
        Rejected
        //HRApproved,
        //ManagerApproved,
        //FinanceApproved,
        //FinalApproved,
    }
}