﻿namespace PeerageHRIS.Enumeration
{
    public enum MaritalStatus
    {
        Single,
        Married,
        Divorced,
        Widowed,
        Separated
    }
}
