﻿namespace PeerageHRIS.Enumeration
{
    public enum LeaveRequestStatus
    {
        Pending,
        Approved,
        Rejected
    }
}
