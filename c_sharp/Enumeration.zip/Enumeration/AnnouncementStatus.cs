﻿namespace PeerageHRIS.Enumeration
{
    public enum AnnouncementStatus
    {
        Created,
        Posted,
        Expired
    }
}
