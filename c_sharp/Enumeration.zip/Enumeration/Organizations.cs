﻿namespace PeerageHRIS.Enumeration
{
    public enum Organizations
    {
        Govermental,
        NGO,
        Plc,
        Sole
    }
}
