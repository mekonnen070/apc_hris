﻿namespace PeerageHRIS.Enumeration
{
    public enum AttendanceStatus
    {
        Present,
        Absent,
        Late
    }
}
