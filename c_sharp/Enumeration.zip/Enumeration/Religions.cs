﻿namespace PeerageHRIS.Enumeration
{
    public enum Religions
    {
        Islam,
        Christianity,
        Hinduism,
        Buddhism,
        Judaism,
        Other
    }
}
