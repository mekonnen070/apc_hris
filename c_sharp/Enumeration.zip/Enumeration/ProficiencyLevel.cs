﻿namespace PeerageHRIS.Enumeration
{
    public enum ProficiencyLevel
    {
        Beginner,
        Intermediate,
        Expert
    }
}
